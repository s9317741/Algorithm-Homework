//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BST_1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

struct BSTNode                  //�𵲺c�ŧi
{
	struct BSTNode *leftchild;
	int data;
	struct BSTNode *rightchild;

};
struct BSTNode *root;
struct StackNode                         ///stack
{
	struct BSTNode *treenode;
	struct StackNode *next;
};
struct StackNode *top;

TForm1 *Form1;
String line;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)         //Form1
	: TForm(Owner)
{
	BSTMemo->Clear();       //��Memo��l��
}
//---------------------------------------------------------------------------
struct BSTNode * newBSTNode(int x)                   //���J�s�W�`�I
{
	struct BSTNode * node = new struct BSTNode;
	node->data =x;
	node->leftchild = NULL;
	node->rightchild = NULL;
	return node;
}
struct BSTNode *insertBST(struct BSTNode *node, int x)    //���Jstruct(���j)
{
	if(node == NULL) return newBSTNode(x);
	if(x < node->data)
		node->leftchild = insertBST(node->leftchild, x);
	else  if(x > node->data)
		node->rightchild = insertBST(node->rightchild, x);    //���Ƹ�ƧP�_
	else  Form1->BSTMemo->Lines->Add("�s�W����: BST�̤w��"+ IntToStr(x));
    return node;
}

void printBST(struct BSTNode *node)         //�L�X���Ǩ��X�禡
{
	if(node!=NULL)
	{
		printBST(node->leftchild);
		line += IntToStr(node->data)+"_";
		printBST(node->rightchild);
	}
}
void __fastcall TForm1::Button1Click(TObject *Sender)   //���J���(���j)
{
	int data = Edit1->Text.ToInt();
	root = insertBST(root, data);
	line = "BST(���j���J):	";
	printBST(root);
	Form1->BSTMemo->Lines->Add(line);
	Edit1->Text = IntToStr(data+=10);  //�C�s�W�@��Edit1�N�|�۰ʥ[10
}

int InsertBST_NonResursive(int x)  //�D���j���J�禡
{
	struct BSTNode *p, *q;
	p = root;
	q = NULL;
	while(p!=NULL)
	{
		q=p;
		if(x == p->data)   //���Ƹ�ƧP�_
			return 0;
		if(x < p->data)
			p = p->leftchild;
		else
            p = p->rightchild;

	}
	p = new struct BSTNode;
	p->data =x;
    p->leftchild = p->rightchild =NULL;
	if(root == NULL) root = p;
	else if(x < q->data)
		q->leftchild = p;
	else
		q->rightchild = p;
	return 1;
}

void __fastcall TForm1::Button9Click(TObject *Sender)   //�D���j���J
{
	int data = Edit1->Text.ToInt();
	if(InsertBST_NonResursive(data))
	{
		line = "BST(�D���j���J):	";
		printBST(root);
		Form1->BSTMemo->Lines->Add(line);
	}
	else
	{
		Form1->BSTMemo->Lines->Add("�s�W����: BST�̤w��"+Edit1->Text);
	}
	Edit1->Text = IntToStr(data+=10);  //�C�s�W�@��Edit1�N�|�۰ʥ[10
}

void __fastcall TForm1::Button3Click(TObject *Sender)  //�H�����J���
{
	String lineData = "�H���ܼ�:		";
	for(int i = 0;i<Edit3->Text.ToInt();i++)
	{
		int min = Edit4->Text.ToInt();
		int max = Edit5->Text.ToInt();
		int data = min + rand() % (max - min);
		lineData += IntToStr(data)+"-";
		root = insertBST(root, data);
		line = "BST(�H�����J):	";
		printBST(root);
	}
	Form1->BSTMemo->Lines->Add(lineData);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------
struct BSTNode *SearchBST(struct BSTNode *node, int x)    //�j�M���(���j)
{
	if(node == NULL) return NULL;
	if(x == node->data) return node;
	if(x < node->data)
		return SearchBST(node->leftchild, x);
	return  SearchBST(node->rightchild, x);
}

void printSearchResult(struct BSTNode *node, String x)   //�j�M�禡�A���[�s�W
{
	if(node!=NULL)
	{
		Form1->BSTMemo->Lines->Add("��� :	" +�@x);
	}
	else
	{
		 Form1->BSTMemo->Lines->Add(x + " ����Q���.");
		 //�Y��ƻ`�M�L�s�b�Y�s�W�i�JBST
		 root = insertBST(root, x.ToInt());
		 line = "BST(���j���J):	";
		 printBST(root);
		 Form1->BSTMemo->Lines->Add(x + " �w�g�Q���J.");
		 Form1->BSTMemo->Lines->Add(line);
	}
}

void __fastcall TForm1::Button2Click(TObject *Sender)      //�j�M��� (���j)
{
	int data = Edit2->Text.ToInt();
	printSearchResult(SearchBST(root, data), Edit2->Text);
}

struct BSTNode *SearchBST_NonRecursive(struct BSTNode *node, int x)
{
	while(node !=NULL)
	{
		if(x == node->data) return node;
		if(x <node ->data)
			node = node->leftchild;
		else
			node =node->rightchild;
	}
	return NULL;
}

void __fastcall TForm1::Button10Click(TObject *Sender)    //�j�M��� (�D���j)
{
	int data = Edit2->Text.ToInt();
	printSearchResult(SearchBST_NonRecursive(root, data), Edit2->Text);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button8Click(TObject *Sender)     //�M��memo���s
{
	Form1->BSTMemo->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TrackBar1Change(TObject *Sender)  //��ƭӼƪ�Trackbar
{
	Edit3->Text = TrackBar1->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TrackBar2Change(TObject *Sender)  //�d��Min��Trackbar
{
	Edit4->Text = TrackBar2->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::TrackBar3Change(TObject *Sender)  //�d��Max��Trackbar
{
	Edit5->Text = TrackBar3->Position;
}
//---------------------------------------------------------------------------
int DeleteBST_NonRecusion(int x)
{
	struct BSTNode *p, *father, *k, *f;
	p = root;
	father = NULL;
	while(p != NULL)
	{
		if(x == p->data)            //���x�Ҧb���`�I
		{
			if((p->leftchild == NULL)&&(p->rightchild == NULL))//p���𸭸`�I
			{
				if(p == root) root =NULL;
				else if(father->leftchild == p)
					father -> leftchild =NULL;
				else
					father->rightchild =NULL;
				free(p);
			}
			else
			{
				if(p->leftchild !=NULL)      //x���D�l�`�I
				{
					f=p;                        //��Xp���l�𪺳̥k�`�I
					k=p->leftchild;
					while(k->rightchild !=NULL)
					{
						f = k;
						k = k->rightchild;    //k�N���ܭ�p�B
					}
					if(p==f)
						f->leftchild = k->leftchild;
					else
						f->rightchild = k->leftchild;
				 }
                 else                            //p�L�l��A�ˬd�k�l��
				{
					f=p;                        //��Xp�k�l�𪺳̥���
					k=p->rightchild;
					while(k->leftchild !=NULL)
					{
						f = k;
						k = k->leftchild;    //K�Y��P�k�l�𪺳̥���
					}
					if(p==f)                 //k�Y��p����l
						f->rightchild =k->rightchild;
					else
						f->leftchild =k->rightchild;
				}
				p->data = k->data;
				free(k);
			}
			return 1;                       //���\�a�R��x�A�^��1��^�I�s�B
		}
		else                                //�|�����x�A�~�򩹤U�@���h��
		{
			father = p;
			if(x < p->data)
				p=p->leftchild;
			else
				p = p->rightchild;
		}
	}
	return 0;                              //�����x�A�^��0
}


void __fastcall TForm1::Button7Click(TObject *Sender)    //�R�����(�D���j)
{
	int data = Edit6->Text.ToInt();
	if(DeleteBST_NonRecusion(data))
	{
		Form1->BSTMemo->Lines->Add("���\�qBST�R��: "+ Edit6->Text);
		line = "BST(�D���j�R��):	";
		printBST(root);
		Form1->BSTMemo->Lines->Add(line);
	}
	else
	{
		Form1->BSTMemo->Lines->Add("�R������: BST�S�� "+Edit6->Text + " �����");
	}
}
//---------------------------------------------------------------------------
struct BSTNode *InorderSucc(struct BSTNode *node)     //�R��(���j)
{
	struct BSTNode *p = node;
	while(p->leftchild !=NULL)
	{
		p =p->leftchild;
	}
	return p;
}

struct BSTNode *DeleteBST(struct BSTNode *node, int x)    //�R��(���j)
{
	struct BSTNode *temp;
	if(node == NULL) return node;
	if(x < node->data)
		node ->leftchild = DeleteBST(node->leftchild, x);
	else if(x > node->data)
		node ->rightchild = DeleteBST(node->rightchild, x);
	else
	{
		if((node->leftchild ==NULL) || (node->rightchild ==NULL))
		{
			temp = node->leftchild ? node->leftchild:node->rightchild;
			if(temp == NULL)
			{
				temp = node;
				node =NULL;
			}
			else
				*node = *temp;
			free(temp);
		}
		else
		{
			temp = InorderSucc(node->rightchild);
			node->data = temp->data;
			node->rightchild = DeleteBST(node->rightchild, temp->data);
		}

	}
	return node;
}

void __fastcall TForm1::Button11Click(TObject *Sender)      //�R��(���j)
{
	int data = Edit6->Text.ToInt();
	line = "BST(���j�R��):	";
	DeleteBST(root, data);
	printBST(root);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------
void printPreorderBST(struct BSTNode *node)    //�L�X�e�Ǩ��X�禡
{
	if(node!=NULL)
	{
		line += IntToStr(node->data)+"_";
		printPreorderBST(node->leftchild);
		printPreorderBST(node->rightchild);
	}
}

void printPostorderBST(struct BSTNode *node)   //�L�X��Ǩ��X�禡
{
	if(node!=NULL)
	{
		printPostorderBST(node->leftchild);
		printPostorderBST(node->rightchild);
		line += IntToStr(node->data)+"_";
	}
}

void __fastcall TForm1::Button4Click(TObject *Sender)  //�e�Ǩ��X(���j)
{
	line = "�e�Ǩ��X(���j):	";
	printPreorderBST(root);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)  //���Ǩ��X(���j)
{
	line = "���Ǩ��X(���j):	";
	printBST(root);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)   //��Ǩ��X(���j)
{
	line = "��Ǩ��X(���j):	";
	printPostorderBST(root);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------
void push_node(struct BSTNode *node)           //push�禡
{
	struct StackNode *old_top;
	old_top = top;
	top = new struct StackNode;
	top->treenode = node;
	top->next = old_top;
}
struct BSTNode *pop_node()                //Pop�禡
{
	struct BSTNode *Tnode;
	struct StackNode *old_top;
	if(top ==NULL)
	{
		//StackEmpty();
	}
	else
	{
		Tnode = top->treenode;
		old_top = top;
		top = top->next;
		free(old_top);
        return Tnode;
    }
}
void Preorder_Stack(struct BSTNode *node)    //�e��(�D���j)
{
	do
	{
		while(node !=NULL)
		{
            line += IntToStr(node->data)+"_";
			push_node(node);
			node = node->leftchild;
		}
		if(top !=NULL)
		{
			node = pop_node();
			node = node->rightchild;
		}
	}
	while((top!=NULL) || (node!=NULL));
}

void Inorder_Stack(struct BSTNode *node)    //����(�D���j)
{
	do
	{
		while(node !=NULL)
		{
			push_node(node);
			node = node->leftchild;
		}
		if(top !=NULL)
		{
			node = pop_node();
			line += IntToStr(node->data)+"_";
			node = node->rightchild;
		}
	}
	while((top!=NULL) || (node!=NULL));
}

void Postorder_Stack(struct BSTNode *node)    //���(�D���j)
{
	do
	{
		while(node !=NULL)
		{
			line = IntToStr(node->data)+"_" +line;
			push_node(node);
			node = node->rightchild;
		}
		if(top !=NULL)
		{
			node = pop_node();
			node = node->leftchild;
		}
	}
    while((top!=NULL) || (node!=NULL));
}

void __fastcall TForm1::Button13Click(TObject *Sender)    //���Ǩ��X(�D���j)
{
	line = "���Ǩ��X(�D���j):	";
	Inorder_Stack(root);
	Form1->BSTMemo->Lines->Add(line);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button14Click(TObject *Sender)    //��Ǩ��X(�D���j)
{
	line = "";
	Postorder_Stack(root);
	Form1->BSTMemo->Lines->Add("��Ǩ��X(�D���j):	"+line);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button12Click(TObject *Sender)     //�e�Ǩ��X(�D���j)
{
	line = "";
	Preorder_Stack(root);
	Form1->BSTMemo->Lines->Add("�e�Ǩ��X(�D���j):	"+line);
}
//---------------------------------------------------------------------------
struct DrawTNode
{
	struct DrawTNode *leftchild;
	int data;
	int index;
	int x;
	int y;
	struct DrawTNode *rightchild;
};

struct DrawTNode* CopyBSTtoDT(struct BSTNode *TreeRoot, int index, int depth)
{
    if (TreeRoot==NULL) return NULL;
	struct DrawTNode *copyRoot = new struct DrawTNode;
	copyRoot->data = TreeRoot->data;
	copyRoot->index = index;
	copyRoot->y = ceil(log(index+1)/log(2.0));
	copyRoot->x = pow(2, (depth-copyRoot->y)) +
		pow(2,(depth-copyRoot->y)+1)*(index-(pow(2, copyRoot->y-1)-1)-1);
	copyRoot->leftchild = CopyBSTtoDT(TreeRoot->leftchild, 2*index, depth);
	copyRoot->rightchild = CopyBSTtoDT(TreeRoot->rightchild, 2*index, depth);
	return copyRoot;
}

int DepthBST(struct BSTNode *node, int level)
{
	int depth, l_depth, r_depth;
	if(node !=NULL)
	{
		l_depth = DepthBST(node->leftchild, level+1);
		r_depth = DepthBST(node->rightchild, level+1);
		depth = (l_depth > r_depth)? l_depth:r_depth;
		return depth;
	}
	else return (level-1);
}

void DrawBST(struct DrawTNode *DrawRoot, int height, int width, int radius)
{
	if(DrawRoot != NULL)
	{
		//Form1->Image1->Canvas->Pen->Color = RGB(0,0,255);
		if(DrawRoot->leftchild !=NULL)
		{
			Form1->Image1->Canvas->MoveTo((DrawRoot->x)*width,
										  (DrawRoot->x)*height);
			Form1->Image1->Canvas->LineTo((DrawRoot->leftchild->x)*width,
										  ((DrawRoot->leftchild->y)*height));
		}
		if(DrawRoot->rightchild !=NULL)
		{
			Form1->Image1->Canvas->MoveTo((DrawRoot->x)*width,
										  (DrawRoot->x)*height);
			Form1->Image1->Canvas->LineTo((DrawRoot->rightchild->x)*width,
										  ((DrawRoot->rightchild->y)*height));
		}
		Form1->Image1->Canvas->Ellipse(((DrawRoot->x)*width)-radius,
									   ((DrawRoot->y)*width)-radius,
									   ((DrawRoot->x)*width)+radius,
									   ((DrawRoot->y)*width)+radius);
		Form1->Image1->Canvas->TextOut((DrawRoot->x)*width-5,
			(DrawRoot->y)*height-8, IntToStr(DrawRoot->data));
		DrawBST(DrawRoot->leftchild, width, height, radius);
        DrawBST(DrawRoot->rightchild, width, height, radius);
	}
}



void __fastcall TForm1::Button15Click(TObject *Sender)
{    /*
	Image1->Picture->Assign(NULL); //Clear Image
	int depth = DepthBST(root, 1);
	BSTMemo->Lines->Add("depth:"+IntToStr(depth));
	int tree_Height = ScrollBox1->Height;
	int tree_Width = ScrollBox1->Width;
	int total_node = pow(2, depth)-1;
	int detW = tree_Width/(total_node+1);
	int detH = tree_Height/(depth+1);
	int node_radius = (detW/2); // radius of a node
	Image1->Top =0;
	Image1->Left = 0;
	Image1->Height = tree_Height;
	Image1->Width = tree_Width;
	struct DrawTNode* DrawRoot=CopyBSTtoDT(root,1,depth);
	DrawBST(DrawRoot, detW, detH, node_radius);
    */
}
//---------------------------------------------------------------------------
