object Form1: TForm1
  Left = 0
  Top = 0
  Caption = #20316#26989#20116'_MST_Kruskal'#39's and Prim'#39's algorithms_'#33865#25919#32752'_05160940'
  ClientHeight = 691
  ClientWidth = 1141
  Color = clSkyBlue
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object PageControl2: TPageControl
    Left = 297
    Top = 0
    Width = 844
    Height = 691
    ActivePage = TabSheet8
    Align = alClient
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = #24494#36575#27491#40657#39636
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    object TabSheet2: TTabSheet
      Caption = 'G'#39's adjacent matrix'
      object Memo1: TMemo
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = #24494#36575#27491#40657#39636
        Font.Style = []
        Lines.Strings = (
          'Memo1')
        ParentFont = False
        ScrollBars = ssVertical
        TabOrder = 0
      end
    end
    object TabSheet3: TTabSheet
      Caption = 'Graph in adjacent matrix'
      ImageIndex = 1
      object StringGrid1: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        Color = clSkyBlue
        FixedColor = clYellow
        TabOrder = 0
      end
    end
    object TabSheet4: TTabSheet
      Caption = 'SSAD Tables'
      ImageIndex = 2
      object StringGrid2: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        TabOrder = 0
      end
    end
    object TabSheet5: TTabSheet
      Caption = 'All pairs'
      ImageIndex = 3
      object StringGrid3: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        TabOrder = 0
      end
    end
    object TabSheet6: TTabSheet
      Caption = 'All pairs table'
      ImageIndex = 4
      object StringGrid4: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        TabOrder = 0
      end
    end
    object TabSheet7: TTabSheet
      Caption = 'Transitive Closure'
      ImageIndex = 5
      object StringGrid5: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        TabOrder = 0
      end
    end
    object TabSheet8: TTabSheet
      Caption = 'MST Found'
      ImageIndex = 6
      object Memo2: TMemo
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        Font.Charset = ANSI_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = #24494#36575#27491#40657#39636
        Font.Style = []
        Lines.Strings = (
          'Memo2')
        ParentFont = False
        ScrollBars = ssVertical
        TabOrder = 0
      end
    end
    object TabSheet9: TTabSheet
      Caption = 'Edges matrix'
      ImageIndex = 7
      object StringGrid6: TStringGrid
        Left = 0
        Top = 0
        Width = 836
        Height = 659
        Align = alClient
        TabOrder = 0
      end
    end
  end
  object PageControl1: TPageControl
    Left = 0
    Top = 0
    Width = 297
    Height = 691
    ActivePage = TabSheet1
    Align = alLeft
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = #24494#36575#27491#40657#39636
    Font.Style = []
    ParentFont = False
    TabOrder = 1
    object TabSheet1: TTabSheet
      Caption = #36664#20837
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = #24494#36575#27491#40657#39636
      Font.Style = []
      ParentFont = False
      object Panel1: TPanel
        Left = 0
        Top = 0
        Width = 289
        Height = 659
        Align = alClient
        Caption = 'Panel1'
        Color = clSkyBlue
        ParentBackground = False
        ShowCaption = False
        TabOrder = 0
        object GroupBox1: TGroupBox
          Left = 16
          Top = 8
          Width = 257
          Height = 314
          Caption = 'G=(V, E)'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -15
          Font.Name = #24494#36575#27491#40657#39636
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 0
          object GroupBox2: TGroupBox
            Left = 11
            Top = 40
            Width = 233
            Height = 233
            Caption = #38568#27231#29986#29983
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 0
            object Label1: TLabel
              Left = 18
              Top = 32
              Width = 24
              Height = 19
              Caption = 'n ='
              Font.Charset = ANSI_CHARSET
              Font.Color = clWindowText
              Font.Height = -15
              Font.Name = #24494#36575#27491#40657#39636
              Font.Style = []
              ParentFont = False
            end
            object Label2: TLabel
              Left = 18
              Top = 65
              Width = 96
              Height = 19
              Caption = 'range(w(e)) ='
              Font.Charset = ANSI_CHARSET
              Font.Color = clWindowText
              Font.Height = -15
              Font.Name = #24494#36575#27491#40657#39636
              Font.Style = []
              ParentFont = False
            end
            object Label3: TLabel
              Left = 18
              Top = 97
              Width = 58
              Height = 19
              Caption = 'if w(e) >'
              Font.Charset = ANSI_CHARSET
              Font.Color = clWindowText
              Font.Height = -15
              Font.Name = #24494#36575#27491#40657#39636
              Font.Style = []
              ParentFont = False
            end
            object Label4: TLabel
              Left = 18
              Top = 131
              Width = 45
              Height = 19
              Caption = 'w(e) ='
              Font.Charset = ANSI_CHARSET
              Font.Color = clWindowText
              Font.Height = -15
              Font.Name = #24494#36575#27491#40657#39636
              Font.Style = []
              ParentFont = False
            end
            object Label5: TLabel
              Left = 18
              Top = 164
              Width = 86
              Height = 19
              Caption = 'source no. ='
              Font.Charset = ANSI_CHARSET
              Font.Color = clWindowText
              Font.Height = -15
              Font.Name = #24494#36575#27491#40657#39636
              Font.Style = []
              ParentFont = False
            end
            object Edit1: TEdit
              Left = 136
              Top = 29
              Width = 81
              Height = 27
              TabOrder = 0
              Text = '8'
            end
            object Edit2: TEdit
              Left = 136
              Top = 62
              Width = 81
              Height = 27
              TabOrder = 1
              Text = '1000'
            end
            object Edit3: TEdit
              Left = 136
              Top = 95
              Width = 81
              Height = 27
              TabOrder = 2
              Text = '300'
            end
            object Edit4: TEdit
              Left = 136
              Top = 128
              Width = 81
              Height = 27
              TabOrder = 3
              Text = '99999'
            end
            object Button1: TButton
              Left = 18
              Top = 194
              Width = 199
              Height = 29
              Caption = #29986#29983' G'
              TabOrder = 4
              OnClick = Button1Click
            end
            object Edit5: TEdit
              Left = 136
              Top = 161
              Width = 81
              Height = 27
              TabOrder = 5
              Text = '2'
            end
          end
          object CheckBox3: TCheckBox
            Left = 25
            Top = 284
            Width = 97
            Height = 17
            Caption = #28961#21521' G'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 1
          end
          object CheckBox1: TCheckBox
            Left = 139
            Top = 284
            Width = 115
            Height = 17
            Caption = 'Echo Print G'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 2
          end
          object Button5: TButton
            Left = 123
            Top = 14
            Width = 105
            Height = 29
            Caption = #35712#20837' G'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 3
            OnClick = Button5Click
          end
        end
        object GroupBox3: TGroupBox
          Left = 16
          Top = 328
          Width = 257
          Height = 153
          Caption = #35336#31639#26368#30701#36335#24465
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -15
          Font.Name = #24494#36575#27491#40657#39636
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 1
          object CheckBox2: TCheckBox
            Left = 23
            Top = 33
            Width = 86
            Height = 17
            Caption = #21360#20986#36942#31243
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 0
          end
          object Button2: TButton
            Left = 23
            Top = 56
            Width = 205
            Height = 25
            Caption = #21934#19968#36215#40670#21040#25152#26377#30446#30340#22320
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 1
            OnClick = Button2Click
          end
          object Button3: TButton
            Left = 23
            Top = 87
            Width = 205
            Height = 25
            Caption = #20219#24847#20841#40670#38291#30340#26368#30701#36335#24465
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 2
            OnClick = Button3Click
          end
          object Button4: TButton
            Left = 23
            Top = 118
            Width = 205
            Height = 25
            Caption = #36958#31227#23553#38281
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 3
            OnClick = Button4Click
          end
        end
        object GroupBox4: TGroupBox
          Left = 16
          Top = 487
          Width = 257
          Height = 154
          Caption = #26368#23567#25104#26412#24310#23637#27193
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -15
          Font.Name = #24494#36575#27491#40657#39636
          Font.Style = [fsBold]
          ParentFont = False
          TabOrder = 2
          object Button6: TButton
            Left = 25
            Top = 32
            Width = 203
            Height = 25
            Caption = 'Kruskal'#28436#31639#27861
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 0
            OnClick = Button6Click
          end
          object Button7: TButton
            Left = 25
            Top = 63
            Width = 203
            Height = 25
            Caption = 'Prim'#28436#31639#27861
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 1
            OnClick = Button7Click
          end
          object CheckBox4: TCheckBox
            Left = 25
            Top = 105
            Width = 192
            Height = 24
            Caption = 'Echo Print Edges In MST'
            Font.Charset = ANSI_CHARSET
            Font.Color = clWindowText
            Font.Height = -15
            Font.Name = #24494#36575#27491#40657#39636
            Font.Style = []
            ParentFont = False
            TabOrder = 2
          end
        end
      end
    end
  end
  object OpenDialog1: TOpenDialog
    Left = 1016
    Top = 48
  end
end
