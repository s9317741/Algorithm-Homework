//---------------------------------------------------------------------------

#ifndef BST_1H
#define BST_1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TMemo *BSTMemo;
	TEdit *Edit1;
	TPanel *BSTPanel;
	TSplitter *Splitter1;
	TEdit *Edit2;
	TButton *Button2;
	TStaticText *StaticText1;
	TEdit *Edit3;
	TStaticText *StaticText2;
	TEdit *Edit4;
	TButton *Button3;
	TEdit *Edit5;
	TButton *Button4;
	TButton *Button5;
	TButton *Button6;
	TEdit *Edit6;
	TButton *Button7;
	TButton *Button8;
	TGroupBox *GroupBox1;
	TButton *Button9;
	TLabel *Label1;
	TGroupBox *GroupBox2;
	TTrackBar *TrackBar1;
	TTrackBar *TrackBar2;
	TTrackBar *TrackBar3;
	TGroupBox *GroupBox3;
	TLabel *Label2;
	TButton *Button10;
	TGroupBox *GroupBox4;
	TLabel *Label3;
	TGroupBox *GroupBox5;
	TButton *Button11;
	TPageControl *PageControl1;
	TTabSheet *TabSheet1;
	TTabSheet *TabSheet2;
	TImage *Image1;
	TPageControl *PageControl2;
	TTabSheet *TabSheet3;
	TButton *Button12;
	TButton *Button13;
	TButton *Button14;
	TButton *Button15;
	TTabSheet *TabSheet4;
	TPanel *Panel1;
	TGroupBox *GroupBox6;
	TLabel *Label4;
	TEdit *Edit7;
	TLabel *Label5;
	TEdit *Edit8;
	TLabel *Label6;
	TEdit *Edit9;
	TLabel *Label7;
	TEdit *Edit10;
	TCheckBox *CheckBox1;
	TButton *Button16;
	TButton *Button17;
	TButton *Button18;
	TTabSheet *TabSheet5;
	TScrollBox *ScrollBox1;
	TButton *Button19;
	TButton *Button20;
	TMemo *Memo1;
	TCheckBox *CheckBox2;
	TButton *Button21;
	TGroupBox *GroupBox7;
	TButton *Button22;
	TCheckBox *CheckBox3;
	TTabSheet *TabSheet6;
	TTabSheet *TabSheet7;
	TPanel *Panel2;
	TGroupBox *GroupBox8;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall TrackBar1Change(TObject *Sender);
	void __fastcall TrackBar2Change(TObject *Sender);
	void __fastcall TrackBar3Change(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button9Click(TObject *Sender);
	void __fastcall Button10Click(TObject *Sender);
	void __fastcall Button11Click(TObject *Sender);
	void __fastcall Button13Click(TObject *Sender);
	void __fastcall Button14Click(TObject *Sender);
	void __fastcall Button12Click(TObject *Sender);
	void __fastcall Button15Click(TObject *Sender);
	void __fastcall Button16Click(TObject *Sender);
	void __fastcall Button20Click(TObject *Sender);
	void __fastcall Button17Click(TObject *Sender);
	void __fastcall Button21Click(TObject *Sender);
	void __fastcall Button18Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
    void DrawTreeFunction();
	void AutoDrawTree();
    void DrawChar();
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
