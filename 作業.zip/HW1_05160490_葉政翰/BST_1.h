//---------------------------------------------------------------------------

#ifndef BST_1H
#define BST_1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.ComCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TMemo *BSTMemo;
	TEdit *Edit1;
	TPanel *BSTPanel;
	TSplitter *Splitter1;
	TEdit *Edit2;
	TButton *Button2;
	TStaticText *StaticText1;
	TEdit *Edit3;
	TStaticText *StaticText2;
	TEdit *Edit4;
	TButton *Button3;
	TEdit *Edit5;
	TButton *Button4;
	TButton *Button5;
	TButton *Button6;
	TEdit *Edit6;
	TButton *Button7;
	TButton *Button8;
	TGroupBox *GroupBox1;
	TButton *Button9;
	TLabel *Label1;
	TGroupBox *GroupBox2;
	TTrackBar *TrackBar1;
	TTrackBar *TrackBar2;
	TTrackBar *TrackBar3;
	TGroupBox *GroupBox3;
	TLabel *Label2;
	TButton *Button10;
	TGroupBox *GroupBox4;
	TLabel *Label3;
	TGroupBox *GroupBox5;
	TButton *Button11;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall TrackBar1Change(TObject *Sender);
	void __fastcall TrackBar2Change(TObject *Sender);
	void __fastcall TrackBar3Change(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button11Click(TObject *Sender);
	void __fastcall Button9Click(TObject *Sender);
	void __fastcall Button10Click(TObject *Sender);

private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
