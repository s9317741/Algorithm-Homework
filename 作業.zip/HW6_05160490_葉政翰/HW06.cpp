﻿// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "HW06.h"
#include <time.h>
#include <math.h>
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner)
{
	Memo1->Clear();
	Memo2->Clear();
}

// ---------------------------------------------------------------------------

clock_t startTime, endTime;

void swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

float SelectionSort(int data[], int n)
{
	startTime = clock();
	int i, j;
	int min, temp;
	for (i = 0; i < n; i++)
	{
		min = i;
		for (j = i + 1; j < n; j++)
			if (data[j] < data[min])
				min = j;
		swap(&data[i], &data[min]);
	}
	endTime = clock();
	float costTime = (float)(endTime - startTime) / CLK_TCK;
	return costTime;
}

float InsertionSort(int data[], int n)
{
	startTime = clock();
	for (int i = 1; i < n; i++)
	{
		int key = data[i];
		int j = i;
		while (key < data[j - 1] && j > 0)
		{
			data[j] = data[j - 1];
			j--;
		}
		data[j] = key;
	}
	endTime = clock();
	float costTime = (float)(endTime - startTime) / CLK_TCK;
	return costTime;
}

float BubbleSort(int data[], int n)
{
	startTime = clock();
	for (int i = n - 1; i > 0; i--)
	{
		for (int j = 1; j <= i; j++)
			if (data[j - 1] > data[j])
				swap(&data[j - 1], &data[j]);
	}
	endTime = clock();
	float costTime = (float)(endTime - startTime) / CLK_TCK;
	return costTime;
}

void QuickSort(int data[], int left, int right)
{
	if (left < right)
	{
		int i = left + 1;
		int j = right;
		int target = data[left];
		do
		{
			while (data[i] <= target)
				i++;
			while (data[j] > target)
				j--;
			if (i < j)
				swap(&data[i], &data[j]);
		}
		while (i < j);
		if (left < j)
			swap(&data[left], &data[j]);
		QuickSort(data, left, j - 1);
		QuickSort(data, j + 1, right);
	}
}

void max_heapify(int arr[], int start, int end)
{
	// 建立父節點指標和子節點指標
	int dad = start;
	int son = dad * 2 + 1;
	while (son <= end)
	{ // 若子節點指標在範圍內才做比較
		if (son + 1 <= end && arr[son] < arr[son + 1]) // 先比較兩個子節點大小，選擇最大的
				son++;
		if (arr[dad] > arr[son]) // 如果父節點大於子節點代表調整完畢，直接跳出函數
				return;
		else
		{ // 否則交換父子內容再繼續子節點和孫節點比较
			swap(&arr[dad], &arr[son]);
			dad = son;
			son = dad * 2 + 1;
		}
	}
}

float heap_sort(int arr[], int len)
{
	startTime = clock();
	int i;
	// 初始化，i從最後一個父節點開始調整
	for (i = len / 2 - 1; i >= 0; i--)
		max_heapify(arr, i, len - 1);
	// 先將第一個元素和已排好元素前一位做交換，再重新調整，直到排序完畢
	for (i = len - 1; i > 0; i--)
	{
		swap(&arr[0], &arr[i]);
		max_heapify(arr, 0, i - 1);
	}
	endTime = clock();
	float costTime = (float)(endTime - startTime) / CLK_TCK;
	return costTime;
}

void Merge(int C[], int k, int A[], int i, int m, int B[], int j, int n)
{
	while ((i <= m) && (j <= n))
	{
		if (A[i] <= B[j])
			C[k++] = A[i++];
		else
			C[k++] = B[j++];
	}
	while (i <= m)
		C[k++] = A[i++];
	while (j <= n)
		C[k++] = B[j++];
}

void MergeSort(int data[], int left, int right)
{
	int m;
	if (left < right)
	{
		m = (left + right) / 2;
		MergeSort(data, left, m);
		MergeSort(data, m + 1, right);
		Merge(data, left, data, left, m, data, m + 1, right);
	}
}

float RadixSort(int data[])
{
	startTime = clock();
	int temp[10][10] =
	{0};
	int order[10] =
	{0};

	int n = 1;
	while (n <= 10)
	{

		int i;
		for (i = 0; i < 10; i++)
		{
			int lsd = ((data[i] / n) % 10);
			temp[lsd][order[lsd]] = data[i];
			order[lsd]++;
		}

		// 重新排列
		int k = 0;
		for (i = 0; i < 10; i++)
		{
			if (order[i] != 0)
			{
				int j;
				for (j = 0; j < order[i]; j++, k++)
				{
					data[k] = temp[i][j];
				}
			}
			order[i] = 0;
		}

		n *= 10;
	}
	endTime = clock();
	float costTime = (float)(endTime - startTime) / CLK_TCK;
	return costTime;
}

void __fastcall TForm1::Button1Click(TObject *Sender)
{
	Memo1->Clear();
	int n = 0, range, times, *data;
	times = StrToInt(Edit1->Text);
	range = StrToInt(Edit3->Text);

	for (int i = 0; i < 7; i++)
		Chart1->Series[i]->Clear();

	for (int t = 1; t <= times; t++)
	{
		if (CheckBox1->Checked)
		{
			Memo2->Lines->Add("------------------ Part" + IntToStr(t) +
				" ----------------\n");
			PageControl1->TabIndex = 1;
		}
		else
			PageControl1->TabIndex = 0;

		n += StrToInt(Edit2->Text);
		data = new int[n + 1];
		for (int i = 0; i < n; i++)
			data[i] = rand() % range + 1;

		if (CheckListBox1->Checked[1])
		{
			float time = InsertionSort(data, n);
			Chart1->Series[1]->Add(time*1000, t);
			if (CheckBox1->Checked)
			{
				Memo2->Lines->Add("插入排序法 " + FloatToStr(time));
			}
			if (t == times)
				Memo1->Lines->Add("插入排序法 (完成)");
		}
		if (CheckListBox1->Checked[0])
		{
			float time = SelectionSort(data, n);
			Chart1->Series[0]->Add(time*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("選擇排序法 " + FloatToStr(time));
			}
			if (t == times)
				Memo1->Lines->Add("選擇排序法 (完成)");

		}
		if (CheckListBox1->Checked[2])
		{
			float time = BubbleSort(data, n);
			Chart1->Series[2]->Add(time*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("泡泡排序法 " + FloatToStr(time));
			}
			if (t == times)
				Memo1->Lines->Add("泡泡排序法 (完成)");
		}
		if (CheckListBox1->Checked[3])
		{
			startTime = clock();
			QuickSort(data, 0, n - 1);
			endTime = clock();
			float costTime = (float)(endTime - startTime) / CLK_TCK;
			Chart1->Series[3]->Add(costTime*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("快速排序法 " + FloatToStr(costTime));
			}
			if (t == times)
				Memo1->Lines->Add("快速排序法 (完成)");
		}
		if (CheckListBox1->Checked[4])
		{
			float time = heap_sort(data, n);
			Chart1->Series[4]->Add(time*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("堆疊排序法 " + FloatToStr(time));
			}
			if (t == times)
				Memo1->Lines->Add("堆疊排序法 (完成)");
		}
		if (CheckListBox1->Checked[5])
		{
			startTime = clock();
			MergeSort(data, 0, n - 1);
			endTime = clock();
			float costTime = (float)(endTime - startTime) / CLK_TCK;
			Chart1->Series[5]->Add(costTime*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("合併排序法 " + FloatToStr(costTime));
			}
			if (t == times)
				Memo1->Lines->Add("合併排序法 (完成)");
		}
		if (CheckListBox1->Checked[6])
		{
			float time = RadixSort(data);
			Chart1->Series[6]->Add(time*1000, t);
			if (CheckBox1->Checked)
			{

				Memo2->Lines->Add("基數排序法 " + FloatToStr(time));
			}
			if (t == times)
				Memo1->Lines->Add("基數排序法 (完成)");
		}
	}
	// Edit1->Text = IntToStr(times*2);
}
// ---------------------------------------------------------------------------
