// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "ShortPath.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner)
{
	Form1->Memo1->Clear();
}
// ---------------------------------------------------------------------------
int **W;
int **A;
int **T;
int n, range, max_range, LargeInt;

void __fastcall TForm1::Button1Click(TObject *Sender)         //����G
{

	if(W !=NULL)
	{
		for(int i=0;i<n;i++) delete W[i];
		delete W;
	}

	n = StrToInt(Edit1->Text);
	range = StrToInt(Edit2->Text);
	max_range = StrToInt(Edit3->Text);
	LargeInt = StrToInt(Edit4->Text);

	W = new int *[n];

	for (int i = 0; i < n; i++)
		W[i] = new int[n];

	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			W[i][j] = rand() % range + 1;
			if (W[i][j] > max_range)
				W[i][j] = LargeInt;
		}
		W[i][i] = LargeInt;
	} // �üƲ��ͤG����٪��۾F�����x�}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if(CheckBox3->Checked)W[j][i] = W[i][j];
			else
			{
                W[i][j] = rand() % range + 1;
				if (W[i][j] > max_range)
					W[i][j] = LargeInt;
            }
		}
	}

	if(CheckBox1->Checked)
	{
        StringGrid1->RowCount = n+1;
		StringGrid1->ColCount = n+1;
		for (int i = 0; i < n; i++)
		{
			StringGrid1->Cells[0][i+1] = i;
			StringGrid1->Cells[i+1][0] = i;
			for (int j = 0; j < n; j++)
			{
				StringGrid1->Cells[j+1][i+1] = IntToStr(W[i][j]);
			}
		}
	}
	Form1->PageControl2->TabIndex = 1;
}
// ---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)        //��@�_�I��Ҧ��ت��a
{
	int i,j,k,v;
	int *D = new int [n+1];
	int *C = new int [n+1];
	int u = StrToInt(Edit5->Text);     //�_�I

	bool *found = new bool [n+1];      //�O�_��쪺�}�C�ŧi

	D[n] = LargeInt;                       //���F���᭱�M��̤p��min���̤j��
	for(j=0; j<n; j++)
	{
		D[j] = W[u][j];
		C[j] = u;
		found[j] = false;
	}
	found[n+1] = true;
	found[u] = true;
	D[u] = 0;

	StringGrid2->RowCount = n+1;
	StringGrid2->ColCount = n+2;

	if(CheckBox2->Checked)                       //�p�G���ĦL�X���G
	{
		for(i=0;i<n;i++)
		{
			StringGrid2->Cells[0][i+1] = i;
			StringGrid2->Cells[i+1][0] = i;
			StringGrid2->Cells[1][i+1] = D[i];
			if(D[i] < LargeInt)
			{
				StringGrid2->Canvas->Font->Color = clYellow;
            }
        }
    }

	int count =1;
	while(count < n)                         //�|���D�X���Ҧ��ت��a���̵u�Z��
	{
		int min =n;
		for(i=0;i<n;i++)
			if(found[i] == false)            //�D�X�_�Iu�H�~���̤p��
				if(D[i]<D[min]) min =i;     //���̤p�A��i��min
		if(CheckBox2->Checked)
			for(i=0;i<n;i++)
			{
			   StringGrid2->Canvas->Font->Color = clYellow;
			}
		Memo1->Lines->Add("min = "+IntToStr(min));

		if(found[min] == true) break;
		k=min;
		found[k] = true;

		for(v=0;v<n;v++)                                   //�M��̵u���|
		{
			if(found[v] == false)
			{
				if(k == n)
				{
					if(D[k]+LargeInt < D[v])
					{
						D[v] = D[k]+LargeInt;
						C[v] = k;                       //����from where
					}
				}
				else if(D[k]+W[k][v] < D[v])
				{
					D[v] = D[k]+W[k][v];
					C[v] = k;
				}
			}
			if(CheckBox2->Checked)
				StringGrid2->Cells[count+1][v+1] = D[v];

		}
		count++;
	}

	if(count < n) Memo1->Lines->Add("No solution for this case!");
	else
	{
		StringGrid2->Cells[n+1][0] = "from";
		for(i=0;i<n;i++)
		{
			StringGrid2->Cells[n+1][i+1] = C[i];
			StringGrid2->Canvas->Font->Color = clYellow;
		}
		String path ="";
		for(i=0;i<n;i++)
		{
			int a,b;
			path = IntToStr(i);
			for(b=i, a=C[b]; a!=u;b=a,a=C[b])
				path = IntToStr(a)+"--[" + IntToStr(W[a][b]) + "]-->" +path;
			path = IntToStr(u)+"--["+IntToStr(W[u][b])+"]-->"+path;
			if(i != u) Memo1->Lines->Add("The shortest distance from " + IntToStr(u)+ " to "+ IntToStr(i)+ " is " + IntToStr(D[i])+" with path " + path);
		}
	}
	Form1->PageControl2->TabIndex = 2;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)      //All pairs
{
	int i, j, k;
	int **AP;
	Form1->PageControl2->TabIndex = 3;
	A = new int *[n];
	for(i=0;i<n;i++)
		A[i] =new int [n];
	AP = new int *[n];
	for(i=0;i<n;i++)
		AP[i] = new int [n];

	for(i=0;i<n;i++)                                //�]�w����
	{
		for(j=0;j<n; j++)
		{
			A[i][j] = W[i][j];
			AP[i][j] = i;
		}
		A[i][i] =0;
	}

	for(k=0;k<n;k++)                                 //�D�n�{��
		for(i=0;i<n;i++)
			for(j=0;j<n; j++)
				if(A[i][k]+A[k][j] < A[i][j])
				{
					A[i][j] = A[i][k]+A[k][j];
					AP[i][j] =k;
				}
	if(CheckBox2->Checked)
	{
		StringGrid3->RowCount = n+1;
		StringGrid3->ColCount = n+1;
		StringGrid4->RowCount = n+1;
		StringGrid4->ColCount = n+1;

		for(i=0;i<n;i++)
		{
			StringGrid3->Cells[0][i+1] = i;
			StringGrid3->Cells[i+1][0] = i;
			StringGrid4->Cells[0][i+1] = i;
			StringGrid4->Cells[i+1][0] = i;
			for(j=0;j<n; j++)
			{
				StringGrid3->Cells[j+1][i+1] = A[i][j];
				StringGrid4->Cells[j+1][i+1] = AP[i][j];
			}
		}
	}
	String path ="";
	int count = 0;
	for(j=0;j<n;j++)
	{
		path ="";
        for(i=0;i<n;i++)
		{
			int a,b;
			count = 0;
			path = IntToStr(i);
			for(b=i, a=AP[j][b]; a!=j;b=a,a=AP[j][b])
			{
				path = IntToStr(a)+"--[" + IntToStr(A[a][b]) + "]-->" +path;
				count+=  A[a][b];
			}
			path = IntToStr(j)+"--["+IntToStr(A[j][b])+"]-->"+path;
			count+= A[j][b];
			if(i != j) Memo1->Lines->Add("The shortest distance from " + IntToStr(j)+ " to "+ IntToStr(i)+ " is " + IntToStr(count)+" with path " + path);
		}
		Memo1->Lines->Add("--------");
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)        //Transitive Closure
{
	int i,j,k;
	Form1->PageControl2->TabIndex = 5;
	T = new int *[n];
    for(i=0;i<n;i++)
		T[i] =new int [n];

	for (i = 0; i < n; i++)                               //�]�w��
		for (j = 0; j < n; j++)
			if(A[i][j] == LargeInt || i==j)
				T[i][j] = 0;
			else
				T[i][j] = 1;

	for(k=0;k<n;k++)                                        //�M�����Y
		for(i=0;i<n;i++)
			for(j=0;j<n; j++)
				T[i][j] = T[i][j] || (T[i][k] && T[k][j]);

	if(CheckBox2->Checked)
	{
		StringGrid5->RowCount = n+1;
		StringGrid5->ColCount = n+1;
		for(i=0;i<n;i++)
		{
			StringGrid5->Cells[0][i+1] = i;
			StringGrid5->Cells[i+1][0] = i;
			for(j=0;j<n; j++)
			{
				StringGrid5->Cells[j+1][i+1] = T[i][j];;
			}
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)            //Ū��
{
	int i,j,k;
	FILE *fp;
	AnsiString fname;

	if(Form1->OpenDialog1->Execute())
	{
		fname = Form1->OpenDialog1->FileName;
		fp = fopen(fname.c_str(), "r+");


		fscanf(fp, "%d", &n);
		fscanf(fp, "%d", &range);
		fscanf(fp, "%d", &max_range);
		fscanf(fp, "%d", &LargeInt);
	}
	Form1->Memo1->Lines->Add("n="+IntToStr(n));
	Form1->Memo1->Lines->Add("range="+IntToStr(range));
	Form1->Memo1->Lines->Add("max_range="+IntToStr(max_range));
	Form1->Memo1->Lines->Add("LargeInt="+IntToStr(LargeInt));

	if(W !=NULL)
	{
		for(int i=0;i<n;i++) delete W[i];
		delete W;
	}

	W = new int *[n];
	for (int i = 0; i < n; i++)
		W[i] = new int[n];

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++)
			fscanf(fp, "%d", &W[i][j]);

	if(CheckBox2->Checked)
	{
		Form1->StringGrid1->RowCount = n+1;
		Form1->StringGrid1->ColCount = n+1;

		for(i=0;i<n;i++)
		{
			StringGrid1->Cells[0][i+1] = i;
			StringGrid1->Cells[i+1][0] = i;
			for(j=0;j<n;j++)
			{
				Form1->StringGrid1->Cells[j+1][i+1] = W[i][j];
			}
        }
	}

}
//---------------------------------------------------------------------------

